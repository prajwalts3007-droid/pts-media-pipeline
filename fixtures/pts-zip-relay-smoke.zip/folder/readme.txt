Temporary synthetic ZIP-to-bucket relay smoke test.
